function results = computeRK4 (y, f, h)
    k1 = f (y);
    k2 = f (y + k1 .* h/2);
    k3 = f (y + k2 .* h/2);
    k4 = f (y + k3 .* h);

    phi = 1/6 * (k1 + 2*k2 + 2*k3 + k4);
    results = y + phi * h;
end