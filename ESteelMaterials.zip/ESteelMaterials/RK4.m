%Elisabeth Steel, GE Detroit Industrial Hack
%Fourth Order Runge-Kutta Method
%RK numerical method code adapted from Dennis Ceh to our application:
    %solving a system of differential equations that model
    %modeling degradation products of key reactions in combination with
    %changing Environmental parameters
    
%need to pass inputs y, f, h

%aging kinetics
%reaction rate = dC/dt = -kC^n
    %n = reaction order, C concentration of reactant, t time, k rate
    
    %paper in terms of cellulose depolymerization:
        %first-order kinetic equation:
            %1/(DPn(t)) - 1/(DPn(0) = kt
            %where denominators are the number-average degree of
            %polymeriation at the start and after a time t
            %applied to thermal degradation
                %k reaction rate dependent on temperature
                    % k = A.*e(-E/RT)
                        % E activation energy (kJ mol-1)
                        % R gas constant
                        % T absolute temperature
                        
    %rate constants 
        %constant humidity of 75%
            %k = 
                        
    
Index = 2;
P_RK4 = p(1);
Et_RK4 = [0];
et_RK4 = [0];
for i = 1:(length(times)-1)
    
    % compute the RK4 results at step i+1 using the values at i
    results = computeRK4 (P_RK4 (i), dpdt, h);
    
    % append the results to the previous results
    P_RK4 = [ P_RK4, results ];

    % compute the error only at the known measured values 
    if (times (i+1) == t(Index))
        Et_current = abs (results - p(Index));
        Et_RK4 = [ Et_RK4, Et_current ];
        et_RK4 = [ et_RK4, Et_current / p(Index) * 100 ];
        Index = Index + 1;
    end
    
end